**Road66 proto readme.

Before playing:
-make sure to unzip the game folder before playing.
-check that you have Linux or Windows.
-make sure to keep .exe files with the folders.
-try to start the game in the biggest terminal possible.

In the game:
-Don't rush, take time to read.
-If any crashes or bugs appear, hit ctrl+C key and restart the game.
-Don't try to resize the terminal during the game, you may do it before starting it, but not while execution.

Thanks to play our game!