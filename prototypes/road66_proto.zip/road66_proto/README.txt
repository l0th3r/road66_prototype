-Extraire le dossier "road66_proto"
-lancer road66.exe
-toujour laisser road66.exe et "proto_dial" ensemble.

-il y a des pb de fenetre etc, ce sera corriger avec le proto.

Si possible lancez le depuis un terminal en plein écran:

>./road66.exe