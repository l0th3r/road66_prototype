#ifndef ROAD66_SECONDARY_EVENTS
#define ROAD66_SECONDARY_EVENTS

void after_event_clear(WINDOW * win_ev, WINDOW * win_me);
void intro(WINDOW * win_ev, WINDOW * win_me, int ev_w);
void secondary_event_1(WINDOW * win_ev, WINDOW * win_me, int ev_w);
void secondary_event_2(WINDOW * win_ev, WINDOW * win_me, int ev_w);
void secondary_event_3(WINDOW * win_ev, WINDOW * win_me, int ev_w);
void secondary_event_4(WINDOW * win_ev, WINDOW * win_me, int ev_w);
void secondary_event_5(WINDOW * win_ev, WINDOW * win_me, int ev_w);
void secondary_event_6(WINDOW * win_ev, WINDOW * win_me, int ev_w);
void secondary_event_7(WINDOW * win_ev, WINDOW * win_me, int ev_w);


#endif